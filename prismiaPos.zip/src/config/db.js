const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const env = require('./env');

const dbPath = path.resolve(process.cwd(), env.db.path);
const dbDir = path.dirname(dbPath);

if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
}

const db = new Database(dbPath);

db.pragma('foreign_keys = ON');
db.pragma('journal_mode = WAL');
db.pragma('busy_timeout = 5000');

console.log(`Base de datos SQLite conectada: ${dbPath}`);

module.exports = db;